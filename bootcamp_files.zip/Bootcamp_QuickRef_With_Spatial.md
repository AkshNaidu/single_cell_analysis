# 3-DAY BOOTCAMP QUICK REFERENCE CARD
## Single-Cell + Spatial Transcriptomics

---

## SINGLE-CELL RNA-SEQ COMMANDS

### Data Loading
```r
data <- Read10X(data.dir = "path/to/data/")
pbmc <- CreateSeuratObject(counts = data, min.cells = 3, min.features = 200)
```

### QC & Filtering
```r
pbmc[["percent.mt"]] <- PercentageFeatureSet(pbmc, pattern = "^MT-")
pbmc <- subset(pbmc, subset = nFeature_RNA > 200 & nFeature_RNA < 2500 & percent.mt < 5)
```

### Normalization
```r
pbmc <- NormalizeData(pbmc)
pbmc <- FindVariableFeatures(pbmc, nfeatures = 2000)
pbmc <- ScaleData(pbmc)
```

### Clustering
```r
pbmc <- RunPCA(pbmc)
pbmc <- FindNeighbors(pbmc, dims = 1:10)
pbmc <- FindClusters(pbmc, resolution = 0.5)
pbmc <- RunUMAP(pbmc, dims = 1:10)
```

### Visualization
```r
DimPlot(pbmc, reduction = "umap", label = TRUE)
FeaturePlot(pbmc, features = c("CD3D", "CD14"))
VlnPlot(pbmc, features = "CD3D")
DotPlot(pbmc, features = markers)
```

---

## SPATIAL TRANSCRIPTOMICS COMMANDS

### Loading Spatial Data
```r
library(hdf5r)
brain <- Load10X_Spatial(
  data.dir = "path/to/spatial/",
  filename = "filtered_feature_bc_matrix.h5",
  slice = "section1"
)
```

### Spatial QC
```r
brain[["percent.mt"]] <- PercentageFeatureSet(brain, pattern = "^MT-")
SpatialFeaturePlot(brain, features = "nCount_Spatial")
SpatialFeaturePlot(brain, features = "nFeature_Spatial")
```

### Normalization (Spatial)
```r
brain <- SCTransform(brain, assay = "Spatial", verbose = FALSE)
```

### Clustering (Spatial)
```r
brain <- RunPCA(brain, assay = "SCT")
brain <- FindNeighbors(brain, dims = 1:30)
brain <- FindClusters(brain, verbose = FALSE)
brain <- RunUMAP(brain, dims = 1:30)
```

### Spatial Visualization
```r
# View tissue image
SpatialPlot(brain, pt.size.factor = 1.6)

# Clusters on tissue
SpatialDimPlot(brain, label = TRUE, label.size = 3)

# Gene expression on tissue
SpatialFeaturePlot(brain, features = "GENE", pt.size.factor = 1.8)

# Multiple features
SpatialFeaturePlot(brain, features = c("GENE1", "GENE2", "GENE3"), ncol = 3)
```

### Spatially Variable Genes
```r
brain <- FindSpatiallyVariableFeatures(brain, 
                                       assay = "SCT",
                                       features = VariableFeatures(brain)[1:1000],
                                       selection.method = "moransi")

# Get top spatial genes
top_spatial <- head(SpatiallyVariableFeatures(brain), 10)
```

---

## CANONICAL MARKERS

### PBMC Cell Types
| Cell Type | Markers |
|-----------|---------|
| Naive CD4+ T | IL7R, CCR7 |
| Memory CD4+ T | IL7R, S100A4 |
| CD8+ T | CD8A |
| B cells | MS4A1, CD79A |
| CD14+ Mono | CD14, LYZ |
| FCGR3A+ Mono | FCGR3A, MS4A7 |
| NK | GNLY, NKG7 |
| DC | FCER1A, CST3 |
| Platelets | PPBP |

### Brain Region Markers
| Region | Markers |
|--------|---------|
| Cortical neurons | NRGN, SLC17A7 |
| Hippocampus | PROX1 |
| Oligodendrocytes | MBP, MOG, PLP1 |
| Astrocytes | AQP4, GFAP |
| Microglia | TMEM119, P2RY12 |

---

## KEY CONCEPTS

### Single-Cell RNA-seq
- **Resolution**: Single cells
- **Output**: Gene expression per cell
- **Spatial info**: NO
- **Typical spots/cells**: 1,000-10,000
- **Use for**: Cell type identification, rare cell discovery, developmental trajectories

### Spatial Transcriptomics (10X Visium)
- **Resolution**: ~55μm spots (~10 cells/spot)
- **Output**: Gene expression + XY coordinates
- **Spatial info**: YES
- **Typical spots**: 3,000-5,000
- **Use for**: Tissue architecture, spatial patterns, niche identification, cell-cell interactions

---

## COMMON ERRORS & FIXES

### "Cannot find h5 file"
```r
# Check file path
file.exists("data/spatial/filtered_feature_bc_matrix.h5")

# May need to install hdf5r
install.packages('hdf5r')
```

### "Spatial images not found"
```r
# Ensure you have these files:
# - tissue_positions_list.csv
# - tissue_hires_image.png
# - tissue_lowres_image.png
# - scalefactors_json.json

# Check directory structure
list.files("data/spatial/spatial/")
```

### "SCTransform fails"
```r
# Try with fewer features
brain <- SCTransform(brain, assay = "Spatial", 
                    variable.features.n = 2000,
                    verbose = FALSE)
```

### "Out of memory"
```r
# Clear workspace
rm(list = ls())
gc()

# Or reduce data size
brain <- brain[, sample(colnames(brain), 2000)]
```

---

## QUALITY METRICS

### Single-Cell (PBMC)
- **nFeature_RNA**: 200-2,500 (genes per cell)
- **nCount_RNA**: 500-20,000 (UMIs per cell)
- **percent.mt**: <5%
- **Cells after filter**: ~2,600

### Spatial (Brain)
- **nFeature_Spatial**: 1,000-8,000 (genes per spot)
- **nCount_Spatial**: 2,000-30,000 (UMIs per spot)
- **percent.mt**: <10% (usually higher than scRNA-seq)
- **Spots**: ~3,000-4,000

---

## SAVE/LOAD WORKFLOW

```r
# Save Seurat objects
saveRDS(pbmc, "results/pbmc_processed.rds")
saveRDS(brain, "results/spatial_processed.rds")

# Load
pbmc <- readRDS("results/pbmc_processed.rds")
brain <- readRDS("results/spatial_processed.rds")

# Save plots
ggsave("output.png", plot, width = 10, height = 8, dpi = 300)

# Save tables
write.csv(markers, "results/markers.csv", row.names = FALSE)
```

---

## GIT WORKFLOW

```bash
# After each major script
git add scripts/XX_*.R
git add figures/
git commit -m "Completed [analysis step]"

# At end of day
git push origin main

# Check status
git status
git log --oneline
```

---

## TROUBLESHOOTING

### Spatial Plots Look Wrong
```r
# Adjust point size
SpatialFeaturePlot(brain, features = "GENE", pt.size.factor = 2)

# Adjust transparency
SpatialFeaturePlot(brain, features = "GENE", alpha = c(0.1, 1))

# Crop to region of interest
SpatialFeaturePlot(brain, features = "GENE", crop = TRUE)
```

### Clusters Don't Make Sense
```r
# Try different resolution
brain <- FindClusters(brain, resolution = 0.3)  # Fewer clusters
brain <- FindClusters(brain, resolution = 0.8)  # More clusters

# Try different number of PCs
brain <- FindNeighbors(brain, dims = 1:20)  # More dimensions
brain <- FindNeighbors(brain, dims = 1:10)  # Fewer dimensions
```

---

## EXPECTED TIMELINE

| Day | Time | Task | Key Output |
|-----|------|------|------------|
| **Day 1** | 8h | scRNA-seq basics | Clusters, markers |
| | 2h | QC + Normalization | Filtered data |
| | 2h | PCA + Clustering | UMAP plot |
| | 2h | Find markers | Heatmap |
| | 2h | Annotation | Cell types |
| **Day 2** | 8h | scRNA-seq advanced | DEG, prep spatial |
| | 2h | Cell types | Labeled UMAP |
| | 2h | DEG analysis | Volcano plot |
| | 2h | Proportions | Bar charts |
| | 2h | Spatial intro | Data downloaded |
| **Day 3** | 8h | Spatial analysis | Complete portfolio |
| | 2h | Load + QC | Tissue image |
| | 2h | Clustering | Spatial clusters |
| | 2h | Variable genes | Spatial patterns |
| | 2h | Documentation | GitHub repo |

---

## INTERVIEW TALKING POINTS

### For Single-Cell:
"I performed complete scRNA-seq analysis including quality control, normalization using LogNormalize, dimensionality reduction with PCA and UMAP, Louvain clustering, and cell type annotation using canonical markers. I identified 9 distinct immune cell populations in PBMC data."

### For Spatial:
"I analyzed 10X Visium spatial data, mapping gene expression patterns directly onto tissue sections. I used Moran's I to identify spatially variable genes, performed spatial clustering to define tissue domains, and characterized region-specific marker genes. The analysis revealed clear spatial organization corresponding to anatomical brain structures."

### Key Phrases:
- "Spatially variable genes"
- "Moran's I statistic"
- "Tissue microenvironment"
- "Spatial domains"
- "Niche identification"
- "SCTransform normalization"
- "Spot-level resolution"

---

## WHAT MAKES GOOD SPATIAL PLOTS?

✅ **Good Spatial Plots:**
- Expression overlaid on tissue image
- Visible tissue structure
- Clear color gradients
- Appropriate point size (pt.size.factor = 1.5-2)
- Legend with scale
- Title with gene name

❌ **Poor Spatial Plots:**
- Can't see tissue image
- Points too small/large
- Unclear what's being shown
- No scale bar
- Missing tissue context

---

## DATA SIZES TO EXPECT

### Files You'll Generate:
- **Single-cell RDS**: ~50-100MB
- **Spatial RDS**: ~200-400MB (includes images)
- **Figures**: 1-3MB each
- **CSV results**: <1MB each

### Total Project Size:
- With data: ~2-3GB
- Without raw data: ~500MB
- Just results + figures: ~100MB

**Note**: Don't push raw data to GitHub! Use .gitignore

---

## RESOURCES

### Documentation:
- Seurat: https://satijalab.org/seurat/
- Spatial vignettes: https://satijalab.org/seurat/articles/spatial_vignette.html
- 10X Genomics: https://support.10xgenomics.com/

### When Stuck:
1. Google the error message
2. Check Seurat GitHub issues
3. Biostars.org
4. Stack Overflow

### Learn More:
- OSCA book (online)
- Nature Methods papers on spatial
- 10X Genomics webinars

---

## FINAL CHECKLIST

### By End of Day 3:
✅ All 14 scripts run successfully  
✅ 30+ figures generated  
✅ scRNA-seq analysis complete  
✅ Spatial analysis complete  
✅ README written  
✅ GitHub repo online  
✅ Can explain both technologies  
✅ **Ready to apply to Koplev lab!**  

---

## EMERGENCY COMMANDS

### If R Crashes:
```r
save.image("backup.RData")
.rs.restartR()  # RStudio
```

### If Need to Restart Analysis:
```r
# Load last checkpoint
pbmc <- readRDS("results/pbmc_clustered.rds")
brain <- readRDS("results/spatial_clustered.rds")
```

### If Git Problems:
```bash
# Undo last commit (keep changes)
git reset --soft HEAD~1

# See what changed
git diff

# Discard all uncommitted changes (CAREFUL!)
git reset --hard HEAD
```

---

## CELEBRATION CHECKLIST

When finished:
🎉 Screenshot your GitHub repo  
🎉 Update your CV with both skills  
🎉 Practice your 5-minute explanation  
🎉 Apply to Koplev position  
🎉 Share success on LinkedIn (optional)  
🎉 **You now have REAL spatial transcriptomics experience!**  

---

## KEY DIFFERENCES: scRNA vs Spatial

| Feature | scRNA-seq | Spatial |
|---------|-----------|---------|
| Resolution | Single-cell | Multi-cell spots |
| Spatial info | ❌ No | ✅ Yes |
| Cell type ID | ✅ Excellent | ⚠️ Deconvolution needed |
| Tissue context | ❌ No | ✅ Yes |
| Rare cells | ✅ Can detect | ⚠️ May miss |
| Niches | ❌ Can't see | ✅ Can identify |
| Cost per sample | $ | $$$ |
| Best for | Cell types, trajectories | Architecture, niches |

**Bottom line**: They're complementary! Use both when possible.

---

**Keep this card open during your 3-day bootcamp!**  
**Day 1-2: Focus on scRNA-seq section**  
**Day 3: Focus on spatial section**  
**You've got this!** 🚀🔬
