# 3-DAY SINGLE-CELL + SPATIAL TRANSCRIPTOMICS BOOTCAMP
## Complete scRNA-seq + Spatial Analysis Portfolio in 72 Hours

**Goal:** By end of Day 3, you'll have BOTH single-cell AND spatial transcriptomics analyses on GitHub that you can discuss confidently in interviews.

**What You'll Build:** 
- Day 1-2: Complete scRNA-seq analysis of PBMC 3k
- Day 3: Spatial transcriptomics analysis of 10X Visium data
- One comprehensive GitHub repository demonstrating both skills

---

## PREPARATION (Do This Now - 45 mins)

### 1. Install Required Software
```r
# In R console:
install.packages('Seurat')
install.packages('SeuratObject')
install.packages('dplyr')
install.packages('ggplot2')
install.packages('patchwork')
install.packages('hdf5r')  # For spatial data
install.packages('viridis')  # Color scales for spatial plots
```

### 2. Download Datasets

**Single-cell PBMC 3k:**
```bash
wget https://cf.10xgenomics.com/samples/cell/pbmc3k/pbmc3k_filtered_gene_bc_matrices.tar.gz
tar -xzf pbmc3k_filtered_gene_bc_matrices.tar.gz
```

**Spatial: Human Brain Section (10X Visium):**
```bash
# This is ~500MB, be patient
wget https://cf.10xgenomics.com/samples/spatial-exp/1.1.0/V1_Human_Brain_Section_1/V1_Human_Brain_Section_1_filtered_feature_bc_matrix.h5
wget https://cf.10xgenomics.com/samples/spatial-exp/1.1.0/V1_Human_Brain_Section_1/V1_Human_Brain_Section_1_spatial.tar.gz
tar -xzf V1_Human_Brain_Section_1_spatial.tar.gz
```

### 3. Setup GitHub Repo
```bash
mkdir scrna-spatial-analysis
cd scrna-spatial-analysis
git init
```

### 4. Create Project Structure
```bash
mkdir -p data/scrna data/spatial scripts figures results
touch README.md
```

---

## DAY 1: SINGLE-CELL BASICS (8 hours)

### HOUR 1-2: Setup + QC + Filtering (9am-11am)

**File: `scripts/01_scrna_preprocessing_qc.R`**

```r
# ==========================================
# SINGLE-CELL ANALYSIS: QC & PREPROCESSING
# ==========================================

library(Seurat)
library(dplyr)
library(ggplot2)
library(patchwork)

setwd("~/scrna-spatial-analysis")

# Load single-cell data
pbmc.data <- Read10X(data.dir = "data/scrna/filtered_gene_bc_matrices/hg19/")

# Create Seurat object
pbmc <- CreateSeuratObject(counts = pbmc.data, 
                           project = "pbmc3k", 
                           min.cells = 3, 
                           min.features = 200)

cat("Initial dimensions:\n")
print(dim(pbmc))

# Calculate QC metrics
pbmc[["percent.mt"]] <- PercentageFeatureSet(pbmc, pattern = "^MT-")
pbmc[["percent.ribo"]] <- PercentageFeatureSet(pbmc, pattern = "^RP[SL]")

# Visualize QC metrics BEFORE filtering
p1 <- VlnPlot(pbmc, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), 
              ncol = 3, pt.size = 0.1) +
  plot_annotation(title = "QC Metrics Before Filtering")
ggsave("figures/01_scrna_qc_before_filter.png", p1, width = 14, height = 5)

# Feature-feature relationships
p2 <- FeatureScatter(pbmc, feature1 = "nCount_RNA", feature2 = "percent.mt") +
  ggtitle("UMI vs Mitochondrial %")
p3 <- FeatureScatter(pbmc, feature1 = "nCount_RNA", feature2 = "nFeature_RNA") +
  ggtitle("UMI vs Gene Count")
p_combined <- p2 + p3
ggsave("figures/02_scrna_qc_scatter.png", p_combined, width = 12, height = 5)

# Apply filters
pbmc <- subset(pbmc, subset = nFeature_RNA > 200 & 
                              nFeature_RNA < 2500 & 
                              percent.mt < 5)

cat("\nAfter filtering:\n")
print(dim(pbmc))
cat("Cells retained:", ncol(pbmc), "\n")
cat("Mean features per cell:", round(mean(pbmc$nFeature_RNA), 1), "\n")
cat("Median features per cell:", median(pbmc$nFeature_RNA), "\n")

# Visualize QC metrics AFTER filtering
p4 <- VlnPlot(pbmc, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), 
              ncol = 3, pt.size = 0.1) +
  plot_annotation(title = "QC Metrics After Filtering")
ggsave("figures/03_scrna_qc_after_filter.png", p4, width = 14, height = 5)

# Save filtered object
saveRDS(pbmc, "results/pbmc_filtered.rds")

cat("\n✓ Preprocessing complete!\n")
```

---

### HOUR 3-4: Normalization + Feature Selection (11am-1pm)

**File: `scripts/02_scrna_normalization.R`**

```r
# ==========================================
# SINGLE-CELL ANALYSIS: NORMALIZATION
# ==========================================

library(Seurat)
library(ggplot2)

pbmc <- readRDS("results/pbmc_filtered.rds")

# Normalize
pbmc <- NormalizeData(pbmc, 
                     normalization.method = "LogNormalize", 
                     scale.factor = 10000)

# Find highly variable features
pbmc <- FindVariableFeatures(pbmc, 
                             selection.method = "vst", 
                             nfeatures = 2000)

# Top 10 variable genes
top10 <- head(VariableFeatures(pbmc), 10)
cat("Top 10 variable genes:\n")
print(top10)

# Plot variable features
p1 <- VariableFeaturePlot(pbmc)
p2 <- LabelPoints(plot = p1, points = top10, repel = TRUE, xnudge = 0, ynudge = 0)
ggsave("figures/04_scrna_variable_features.png", p2, width = 12, height = 7)

# Scale data (all genes)
all.genes <- rownames(pbmc)
pbmc <- ScaleData(pbmc, features = all.genes)

saveRDS(pbmc, "results/pbmc_normalized.rds")

cat("\n✓ Normalization complete!\n")
cat("Variable features:", length(VariableFeatures(pbmc)), "\n")
```

---

### HOUR 5-6: PCA + Clustering (2pm-4pm)

**File: `scripts/03_scrna_clustering.R`**

```r
# ==========================================
# SINGLE-CELL ANALYSIS: CLUSTERING
# ==========================================

library(Seurat)
library(ggplot2)

pbmc <- readRDS("results/pbmc_normalized.rds")

# Run PCA
pbmc <- RunPCA(pbmc, features = VariableFeatures(object = pbmc))

# Visualize PCA
p1 <- DimPlot(pbmc, reduction = "pca") + 
  ggtitle("PCA of PBMC")
ggsave("figures/05_scrna_pca.png", p1, width = 8, height = 7)

# Elbow plot
p2 <- ElbowPlot(pbmc, ndims = 50) +
  ggtitle("Elbow Plot - Determining Dimensionality")
ggsave("figures/06_scrna_elbow.png", p2, width = 10, height = 6)

# Use first 10 PCs (based on elbow)
pbmc <- FindNeighbors(pbmc, dims = 1:10)
pbmc <- FindClusters(pbmc, resolution = 0.5)

# Check cluster sizes
cat("\nCluster distribution:\n")
print(table(Idents(pbmc)))

# Run UMAP
pbmc <- RunUMAP(pbmc, dims = 1:10)

# UMAP with clusters
p3 <- DimPlot(pbmc, reduction = "umap", label = TRUE, pt.size = 0.5) +
  ggtitle("UMAP - Cell Clusters")
ggsave("figures/07_scrna_umap_clusters.png", p3, width = 10, height = 8)

saveRDS(pbmc, "results/pbmc_clustered.rds")

cat("\n✓ Clustering complete!\n")
cat("Number of clusters:", length(unique(Idents(pbmc))), "\n")
```

---

### HOUR 7-8: Find Cluster Markers (4pm-6pm)

**File: `scripts/04_scrna_markers.R`**

```r
# ==========================================
# SINGLE-CELL ANALYSIS: MARKER GENES
# ==========================================

library(Seurat)
library(dplyr)

pbmc <- readRDS("results/pbmc_clustered.rds")

# Find all markers
pbmc.markers <- FindAllMarkers(pbmc, 
                               only.pos = TRUE, 
                               min.pct = 0.25, 
                               logfc.threshold = 0.25)

# Top 10 per cluster
top10_markers <- pbmc.markers %>%
  group_by(cluster) %>%
  top_n(n = 10, wt = avg_log2FC)

# Save
write.csv(pbmc.markers, "results/scrna_all_markers.csv", row.names = FALSE)
write.csv(top10_markers, "results/scrna_top10_markers.csv", row.names = FALSE)

# Print top 3 markers per cluster
cat("\nTop 3 markers per cluster:\n")
for(i in sort(unique(pbmc.markers$cluster))) {
  cat("\n=== Cluster", i, "===\n")
  top_genes <- pbmc.markers %>% 
    filter(cluster == i) %>% 
    arrange(desc(avg_log2FC)) %>%
    head(3)
  print(top_genes[, c("gene", "avg_log2FC", "pct.1", "pct.2")])
}

# Heatmap
library(ggplot2)
p1 <- DoHeatmap(pbmc, features = top10_markers$gene) + 
  NoLegend() +
  ggtitle("Top 10 Marker Genes per Cluster")
ggsave("figures/08_scrna_marker_heatmap.png", p1, width = 14, height = 18)

saveRDS(pbmc, "results/pbmc_with_markers.rds")

cat("\n✓ Marker identification complete!\n")
```

**✅ Day 1 Complete!** Single-cell clustering done.

---

## DAY 2: SINGLE-CELL ADVANCED (8 hours)

### HOUR 9-10: Cell Type Annotation (9am-11am)

**File: `scripts/05_scrna_annotation.R`**

```r
# ==========================================
# SINGLE-CELL ANALYSIS: CELL TYPE ANNOTATION
# ==========================================

library(Seurat)
library(ggplot2)

pbmc <- readRDS("results/pbmc_with_markers.rds")

# Annotate based on canonical markers
new.cluster.ids <- c("Naive CD4 T", "CD14+ Mono", "Memory CD4 T", 
                     "B", "CD8 T", "FCGR3A+ Mono", 
                     "NK", "DC", "Platelet")
names(new.cluster.ids) <- levels(pbmc)
pbmc <- RenameIdents(pbmc, new.cluster.ids)

# UMAP with cell types
p1 <- DimPlot(pbmc, reduction = "umap", label = TRUE, pt.size = 0.5) + 
  NoLegend() +
  ggtitle("PBMC Cell Types")
ggsave("figures/09_scrna_umap_celltypes.png", p1, width = 10, height = 8)

# Canonical markers
canonical_markers <- c("IL7R", "CCR7",     # Naive CD4+ T
                       "CD14", "LYZ",       # CD14+ Mono
                       "MS4A1",             # B cells
                       "CD8A",              # CD8+ T
                       "FCGR3A", "MS4A7",   # FCGR3A+ Mono
                       "GNLY", "NKG7",      # NK
                       "FCER1A", "CST3",    # DC
                       "PPBP")              # Platelets

p2 <- FeaturePlot(pbmc, features = canonical_markers[1:9], 
                  ncol = 3, pt.size = 0.1)
ggsave("figures/10_scrna_canonical_markers.png", p2, width = 15, height = 15)

# Dot plot
p3 <- DotPlot(pbmc, features = canonical_markers) + 
  RotatedAxis() +
  ggtitle("Canonical Marker Expression")
ggsave("figures/11_scrna_dotplot.png", p3, width = 14, height = 6)

saveRDS(pbmc, "results/pbmc_annotated.rds")

cat("\n✓ Cell type annotation complete!\n")
cat("\nCell type counts:\n")
print(table(Idents(pbmc)))
```

---

### HOUR 11-12: Differential Expression (11am-1pm)

**File: `scripts/06_scrna_deg.R`**

```r
# ==========================================
# SINGLE-CELL ANALYSIS: DIFFERENTIAL EXPRESSION
# ==========================================

library(Seurat)
library(dplyr)
library(ggplot2)
library(ggrepel)

pbmc <- readRDS("results/pbmc_annotated.rds")

# Compare monocyte populations
mono_de <- FindMarkers(pbmc, 
                       ident.1 = "CD14+ Mono", 
                       ident.2 = "FCGR3A+ Mono",
                       min.pct = 0.25)

mono_de$gene <- rownames(mono_de)

# Significant genes
mono_de$significant <- ifelse(mono_de$p_val_adj < 0.05 & 
                              abs(mono_de$avg_log2FC) > 0.5, 
                              "Significant", "Not Significant")

# Save
write.csv(mono_de, "results/scrna_monocyte_deg.csv", row.names = FALSE)

# Top genes
top_genes <- mono_de %>% 
  filter(significant == "Significant") %>% 
  arrange(desc(abs(avg_log2FC))) %>% 
  head(10)

# Volcano plot
p1 <- ggplot(mono_de, aes(x = avg_log2FC, y = -log10(p_val_adj), 
                          color = significant)) +
  geom_point(alpha = 0.5, size = 1.5) +
  geom_text_repel(data = top_genes, aes(label = gene), 
                  size = 3, max.overlaps = 20, box.padding = 0.5) +
  scale_color_manual(values = c("grey60", "red3")) +
  theme_minimal() +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "grey30") +
  geom_vline(xintercept = c(-0.5, 0.5), linetype = "dashed", color = "grey30") +
  labs(title = "CD14+ Monocytes vs FCGR3A+ Monocytes",
       x = "Log2 Fold Change",
       y = "-Log10 Adjusted P-value",
       color = "") +
  theme(legend.position = "top")

ggsave("figures/12_scrna_volcano.png", p1, width = 10, height = 8)

# Violin plots for top DE genes
top5 <- head(top_genes$gene, 5)
p2 <- VlnPlot(pbmc, features = top5, 
              idents = c("CD14+ Mono", "FCGR3A+ Mono"),
              ncol = 5, pt.size = 0) +
  plot_annotation(title = "Top Differentially Expressed Genes")
ggsave("figures/13_scrna_deg_violin.png", p2, width = 18, height = 4)

cat("\n✓ Differential expression complete!\n")
cat("Significant genes (|log2FC| > 0.5, padj < 0.05):", 
    sum(mono_de$significant == "Significant"), "\n")
```

---

### HOUR 13-14: Cell Proportions + Summary (2pm-4pm)

**File: `scripts/07_scrna_proportions.R`**

```r
# ==========================================
# SINGLE-CELL ANALYSIS: CELL PROPORTIONS
# ==========================================

library(Seurat)
library(ggplot2)
library(dplyr)

pbmc <- readRDS("results/pbmc_annotated.rds")

# Calculate proportions
cell_counts <- table(Idents(pbmc))
cell_props <- prop.table(cell_counts) * 100

prop_df <- data.frame(
  CellType = names(cell_props),
  Proportion = as.numeric(cell_props),
  Count = as.numeric(cell_counts)
)

# Bar plot
p1 <- ggplot(prop_df, aes(x = reorder(CellType, -Proportion), 
                          y = Proportion, fill = CellType)) +
  geom_bar(stat = "identity", width = 0.7) +
  geom_text(aes(label = sprintf("%.1f%%", Proportion)), 
            vjust = -0.5, size = 3.5) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 11),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5, face = "bold")) +
  labs(title = "Cell Type Composition - PBMC Dataset",
       x = "Cell Type",
       y = "Percentage (%)")

ggsave("figures/14_scrna_proportions.png", p1, width = 12, height = 7)

# Pie chart
p2 <- ggplot(prop_df, aes(x = "", y = Proportion, fill = CellType)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar("y", start = 0) +
  theme_void() +
  labs(title = "Cell Type Distribution") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 14))

ggsave("figures/15_scrna_pie_chart.png", p2, width = 9, height = 9)

write.csv(prop_df, "results/scrna_cell_proportions.csv", row.names = FALSE)

cat("\n✓ Cell proportion analysis complete!\n")
print(prop_df)
```

---

### HOUR 15-16: Introduction to Spatial Transcriptomics (4pm-6pm)

**File: `scripts/08_spatial_intro.R`**

```r
# ==========================================
# SPATIAL TRANSCRIPTOMICS: INTRODUCTION
# ==========================================

# Read about spatial transcriptomics while data downloads
# Key concepts:

cat("
=== SPATIAL TRANSCRIPTOMICS KEY CONCEPTS ===

1. WHAT IS IT?
   - Measures gene expression while preserving spatial location
   - Each 'spot' captures transcripts from multiple cells
   - Creates a spatial map of gene expression in tissue

2. 10X VISIUM TECHNOLOGY:
   - Spots are 55μm in diameter
   - Each spot contains ~10 cells (tissue-dependent)
   - Spots are 100μm apart (center to center)
   - Captures full transcriptome

3. KEY DIFFERENCES FROM scRNA-seq:
   - Spots (not single cells)
   - Spatial coordinates preserved
   - Can see tissue architecture
   - Can identify spatial patterns and niches

4. TYPICAL WORKFLOW:
   a) Load spatial data (expression + coordinates + images)
   b) Quality control
   c) Normalization (same as scRNA-seq)
   d) Identify spatial patterns
   e) Visualize on tissue image
   f) Find spatially variable genes
   g) Identify spatial domains/niches

5. APPLICATIONS:
   - Tumor microenvironment mapping
   - Tissue architecture analysis
   - Cell-cell interaction inference
   - Niche identification
   - Disease spatial patterns

===========================================
")

# Verify spatial data is downloaded
spatial_files <- c(
  "data/spatial/filtered_feature_bc_matrix.h5",
  "data/spatial/spatial/tissue_positions_list.csv",
  "data/spatial/spatial/tissue_hires_image.png"
)

cat("\nChecking spatial data files...\n")
for(f in spatial_files) {
  if(file.exists(f)) {
    cat("✓", f, "\n")
  } else {
    cat("✗ MISSING:", f, "\n")
    cat("  Download from: https://support.10xgenomics.com/spatial-gene-expression/datasets\n")
  }
}

cat("\n✓ Ready for Day 3: Spatial Analysis!\n")
```

**✅ Day 2 Complete!** Single-cell analysis finished, ready for spatial!

---

## DAY 3: SPATIAL TRANSCRIPTOMICS (8 hours)

### HOUR 17-18: Load & QC Spatial Data (9am-11am)

**File: `scripts/09_spatial_load_qc.R`**

```r
# ==========================================
# SPATIAL TRANSCRIPTOMICS: LOADING & QC
# ==========================================

library(Seurat)
library(ggplot2)
library(patchwork)
library(hdf5r)

setwd("~/scrna-spatial-analysis")

# Load spatial data
brain <- Load10X_Spatial(
  data.dir = "data/spatial/",
  filename = "filtered_feature_bc_matrix.h5",
  slice = "brain_section"
)

cat("Spatial data dimensions:\n")
print(dim(brain))
cat("Number of spots:", ncol(brain), "\n")
cat("Number of genes:", nrow(brain), "\n")

# Calculate QC metrics
brain[["percent.mt"]] <- PercentageFeatureSet(brain, pattern = "^MT-")

# Visualize QC on tissue
p1 <- SpatialFeaturePlot(brain, features = "nCount_Spatial") + 
  ggtitle("Total UMI Count per Spot")
p2 <- SpatialFeaturePlot(brain, features = "nFeature_Spatial") + 
  ggtitle("Gene Count per Spot")
p_qc <- p1 + p2
ggsave("figures/16_spatial_qc_on_tissue.png", p_qc, width = 16, height = 7)

# QC violin plots
p3 <- VlnPlot(brain, features = c("nCount_Spatial", "nFeature_Spatial", "percent.mt"),
              pt.size = 0.1, ncol = 3) +
  plot_annotation(title = "Spatial QC Metrics")
ggsave("figures/17_spatial_qc_violin.png", p3, width = 14, height = 5)

# View tissue image
p4 <- SpatialPlot(brain, pt.size.factor = 1.6, alpha = 0) +
  ggtitle("Brain Tissue Section - H&E Image")
ggsave("figures/18_spatial_tissue_image.png", p4, width = 10, height = 8)

# Summary statistics
cat("\nQC Summary:\n")
cat("Mean UMI per spot:", round(mean(brain$nCount_Spatial), 1), "\n")
cat("Median UMI per spot:", median(brain$nCount_Spatial), "\n")
cat("Mean genes per spot:", round(mean(brain$nFeature_Spatial), 1), "\n")
cat("Mean % MT:", round(mean(brain$percent.mt), 2), "%\n")

saveRDS(brain, "results/spatial_raw.rds")

cat("\n✓ Spatial data loaded and QC complete!\n")
```

---

### HOUR 19-20: Spatial Normalization & Clustering (11am-1pm)

**File: `scripts/10_spatial_clustering.R`**

```r
# ==========================================
# SPATIAL TRANSCRIPTOMICS: CLUSTERING
# ==========================================

library(Seurat)
library(ggplot2)

brain <- readRDS("results/spatial_raw.rds")

# Normalization (same as scRNA-seq)
brain <- SCTransform(brain, assay = "Spatial", verbose = FALSE)

# Dimensionality reduction and clustering
brain <- RunPCA(brain, assay = "SCT", verbose = FALSE)
brain <- FindNeighbors(brain, reduction = "pca", dims = 1:30)
brain <- FindClusters(brain, verbose = FALSE, resolution = 0.5)
brain <- RunUMAP(brain, reduction = "pca", dims = 1:30)

# Visualize clusters on UMAP
p1 <- DimPlot(brain, reduction = "umap", label = TRUE) +
  ggtitle("Spatial Clusters - UMAP")
ggsave("figures/19_spatial_umap_clusters.png", p1, width = 10, height = 8)

# Visualize clusters on tissue!
p2 <- SpatialDimPlot(brain, label = TRUE, label.size = 3, pt.size.factor = 1.8) +
  ggtitle("Spatial Clusters on Tissue Section")
ggsave("figures/20_spatial_clusters_on_tissue.png", p2, width = 12, height = 10)

# Interactive plot with cells outlined
p3 <- SpatialDimPlot(brain, cells.highlight = CellsByIdentities(brain), 
                     facet.highlight = TRUE, ncol = 4,
                     pt.size.factor = 1.6)
ggsave("figures/21_spatial_clusters_faceted.png", p3, width = 18, height = 12)

cat("\nCluster distribution:\n")
print(table(Idents(brain)))

saveRDS(brain, "results/spatial_clustered.rds")

cat("\n✓ Spatial clustering complete!\n")
```

---

### HOUR 21-22: Spatially Variable Genes (2pm-4pm)

**File: `scripts/11_spatial_variable_genes.R`**

```r
# ==========================================
# SPATIAL TRANSCRIPTOMICS: SPATIALLY VARIABLE GENES
# ==========================================

library(Seurat)
library(ggplot2)

brain <- readRDS("results/spatial_clustered.rds")

# Find spatially variable features
# This identifies genes with spatial patterns
brain <- FindSpatiallyVariableFeatures(brain, 
                                       assay = "SCT",
                                       features = VariableFeatures(brain)[1:1000],
                                       selection.method = "moransi")

# Get top spatial features
top_spatial <- head(SpatiallyVariableFeatures(brain, selection.method = "moransi"), 12)

cat("\nTop 12 spatially variable genes:\n")
print(top_spatial)

# Save list
write.csv(data.frame(gene = top_spatial), 
          "results/spatial_top_variable_genes.csv", 
          row.names = FALSE)

# Visualize top 6 spatially variable genes on tissue
p1 <- SpatialFeaturePlot(brain, features = top_spatial[1:6], 
                         ncol = 3, alpha = c(0.1, 1),
                         pt.size.factor = 1.6)
ggsave("figures/22_spatial_variable_genes_tissue.png", p1, width = 18, height = 12)

# Zoomed in view of top gene
p2 <- SpatialFeaturePlot(brain, features = top_spatial[1], 
                         pt.size.factor = 2, alpha = c(0.1, 1)) +
  ggtitle(paste("Top Spatially Variable Gene:", top_spatial[1]))
ggsave("figures/23_spatial_top_gene_zoomed.png", p2, width = 10, height = 8)

# Ridge plot showing expression distribution
library(ggridges)
p3 <- RidgePlot(brain, features = top_spatial[1:6], ncol = 2) +
  ggtitle("Expression Distribution of Spatially Variable Genes")
ggsave("figures/24_spatial_ridge_plot.png", p3, width = 12, height = 10)

saveRDS(brain, "results/spatial_with_svgs.rds")

cat("\n✓ Spatially variable gene analysis complete!\n")
```

---

### HOUR 23-24: Spatial Cluster Markers & Visualization (4pm-6pm)

**File: `scripts/12_spatial_markers.R`**

```r
# ==========================================
# SPATIAL TRANSCRIPTOMICS: CLUSTER MARKERS
# ==========================================

library(Seurat)
library(ggplot2)
library(dplyr)

brain <- readRDS("results/spatial_with_svgs.rds")

# Find markers for spatial clusters
spatial_markers <- FindAllMarkers(brain, 
                                  only.pos = TRUE,
                                  min.pct = 0.25, 
                                  logfc.threshold = 0.25)

# Top 5 per cluster
top5_spatial <- spatial_markers %>%
  group_by(cluster) %>%
  top_n(n = 5, wt = avg_log2FC)

# Save
write.csv(spatial_markers, "results/spatial_all_markers.csv", row.names = FALSE)
write.csv(top5_spatial, "results/spatial_top5_markers.csv", row.names = FALSE)

# Print top 3 per cluster
cat("\nTop 3 marker genes per spatial cluster:\n")
for(i in sort(unique(spatial_markers$cluster))) {
  cat("\n=== Cluster", i, "===\n")
  top_genes <- spatial_markers %>% 
    filter(cluster == i) %>% 
    arrange(desc(avg_log2FC)) %>%
    head(3)
  print(top_genes[, c("gene", "avg_log2FC", "pct.1", "pct.2")])
}

# Heatmap
p1 <- DoHeatmap(brain, features = top5_spatial$gene, size = 3) +
  ggtitle("Top 5 Markers per Spatial Cluster")
ggsave("figures/25_spatial_marker_heatmap.png", p1, width = 14, height = 12)

# Dot plot
p2 <- DotPlot(brain, features = unique(top5_spatial$gene[1:30])) + 
  RotatedAxis() +
  ggtitle("Marker Expression Across Spatial Clusters")
ggsave("figures/26_spatial_dotplot.png", p2, width = 16, height = 6)

# Visualize select markers on tissue
select_markers <- spatial_markers %>%
  group_by(cluster) %>%
  top_n(n = 1, wt = avg_log2FC) %>%
  pull(gene) %>%
  head(6)

p3 <- SpatialFeaturePlot(brain, features = select_markers, 
                         ncol = 3, alpha = c(0.1, 1),
                         pt.size.factor = 1.6) +
  plot_annotation(title = "Top Marker Gene per Cluster")
ggsave("figures/27_spatial_markers_on_tissue.png", p3, width = 18, height = 12)

saveRDS(brain, "results/spatial_final.rds")

cat("\n✓ Spatial marker analysis complete!\n")
```

---

### HOUR 25-26: Spatial Domain Analysis (6pm-8pm - Optional Evening Work)

**File: `scripts/13_spatial_domains.R`**

```r
# ==========================================
# SPATIAL TRANSCRIPTOMICS: DOMAIN ANALYSIS
# ==========================================

library(Seurat)
library(ggplot2)
library(viridis)

brain <- readRDS("results/spatial_final.rds")

# Annotate major brain regions based on known markers
# (In real analysis, you'd use more markers and domain knowledge)

# Example brain region markers
cortex_markers <- c("NRGN", "SLC17A7")  # Cortical neurons
hippocampus_markers <- c("PROX1")  # Hippocampus
oligodendrocyte_markers <- c("MBP", "MOG")  # White matter

# Visualize region-specific markers
p1 <- SpatialFeaturePlot(brain, 
                         features = c("NRGN", "MBP", "PROX1"), 
                         ncol = 3, alpha = c(0.1, 1),
                         pt.size.factor = 2)
ggsave("figures/28_spatial_region_markers.png", p1, width = 18, height 6)

# Create composite score for cortex
brain <- AddModuleScore(brain, 
                       features = list(cortex_markers), 
                       name = "Cortex_Score")

# Visualize cortex score
p2 <- SpatialFeaturePlot(brain, features = "Cortex_Score1", 
                         pt.size.factor = 2) +
  scale_fill_viridis() +
  ggtitle("Cortical Region Score")
ggsave("figures/29_spatial_cortex_score.png", p2, width = 10, height = 8)

# Summary statistics per cluster
cluster_stats <- data.frame(
  Cluster = names(table(Idents(brain))),
  N_spots = as.numeric(table(Idents(brain))),
  Mean_genes = tapply(brain$nFeature_Spatial, Idents(brain), mean),
  Mean_UMI = tapply(brain$nCount_Spatial, Idents(brain), mean)
)

write.csv(cluster_stats, "results/spatial_cluster_stats.csv", row.names = FALSE)

cat("\nSpatial cluster statistics:\n")
print(cluster_stats)

cat("\n✓ Spatial domain analysis complete!\n")
```

---

### HOUR 27-28: Integration & Comparison (Optional - Next Morning)

**File: `scripts/14_scrna_spatial_comparison.R`**

```r
# ==========================================
# COMPARISON: scRNA-seq vs Spatial
# ==========================================

library(Seurat)
library(ggplot2)
library(patchwork)

# Load both datasets
pbmc <- readRDS("results/pbmc_annotated.rds")
brain <- readRDS("results/spatial_final.rds")

# Create comparison plots

# 1. Technology comparison
tech_comparison <- data.frame(
  Metric = c("Cells/Spots", "Genes Detected", "Resolution", "Spatial Info"),
  scRNAseq = c(ncol(pbmc), nrow(pbmc), "Single-cell", "No"),
  Spatial = c(ncol(brain), nrow(brain), "Multi-cell spots", "Yes")
)

write.csv(tech_comparison, "results/technology_comparison.csv", row.names = FALSE)

cat("\n=== TECHNOLOGY COMPARISON ===\n")
print(tech_comparison)

# 2. Compare marker gene overlap
pbmc_markers <- read.csv("results/scrna_all_markers.csv")
spatial_markers <- read.csv("results/spatial_all_markers.csv")

overlap <- intersect(pbmc_markers$gene, spatial_markers$gene)
cat("\nNumber of overlapping marker genes:", length(overlap), "\n")

# 3. Side-by-side visualization
# Select common genes
common_genes <- c("CD3D", "CD14", "MBP", "NRGN")
common_genes <- common_genes[common_genes %in% rownames(pbmc) & 
                             common_genes %in% rownames(brain)]

if(length(common_genes) > 0) {
  p_sc <- FeaturePlot(pbmc, features = common_genes[1], pt.size = 0.5) +
    ggtitle(paste("scRNA-seq:", common_genes[1]))
  
  p_sp <- SpatialFeaturePlot(brain, features = common_genes[1], 
                             pt.size.factor = 2, alpha = c(0.1, 1)) +
    ggtitle(paste("Spatial:", common_genes[1]))
  
  p_combined <- p_sc + p_sp
  ggsave("figures/30_comparison_example.png", p_combined, width = 16, height = 7)
}

cat("\n✓ Comparison analysis complete!\n")
cat("\n========================================\n")
cat("🎉 CONGRATULATIONS! 🎉\n")
cat("You've completed BOTH single-cell AND spatial transcriptomics analyses!\n")
cat("========================================\n")
```

---

### HOUR 29-30: Documentation & GitHub (Final Hours)

**File: `README.md`**

```markdown
# Single-Cell and Spatial Transcriptomics Analysis Portfolio

## Overview
This repository demonstrates proficiency in both **single-cell RNA-seq** and **spatial transcriptomics** analysis through two comprehensive case studies:

1. **scRNA-seq Analysis**: PBMC 3k dataset - cell type identification and differential expression
2. **Spatial Transcriptomics**: Human brain section - spatial domain mapping and spatially variable genes

## Datasets

### Single-Cell RNA-seq (PBMC 3k)
- **Source**: 10X Genomics
- **Technology**: Chromium Single Cell 3' v1
- **Cells**: 2,700 PBMCs from healthy donor
- **Genes**: ~13,700 detected

### Spatial Transcriptomics (Human Brain)
- **Source**: 10X Genomics Visium
- **Technology**: Spatial Gene Expression
- **Spots**: ~3,600 spatial spots
- **Genes**: ~18,000 detected

## Analysis Workflows

### Part 1: Single-Cell RNA-seq Analysis

#### 1. Quality Control & Preprocessing
- Filtered cells: 200-2,500 genes, <5% mitochondrial content
- Final dataset: 2,638 high-quality cells
- **Scripts**: `01_scrna_preprocessing_qc.R`, `02_scrna_normalization.R`

#### 2. Dimensionality Reduction & Clustering
- Normalization: LogNormalize (scale factor 10,000)
- Variable features: 2,000 genes
- PCA: First 10 components
- Clustering: Louvain algorithm (resolution 0.5)
- Visualization: UMAP
- **Result**: 9 distinct cell clusters identified
- **Scripts**: `03_scrna_clustering.R`, `04_scrna_markers.R`

#### 3. Cell Type Annotation
Identified cell types based on canonical markers:
- **Naive CD4+ T cells**: IL7R+, CCR7+
- **Memory CD4+ T cells**: IL7R+, S100A4+
- **CD8+ T cells**: CD8A+
- **B cells**: MS4A1+
- **CD14+ Monocytes**: CD14+, LYZ+
- **FCGR3A+ Monocytes**: FCGR3A+, MS4A7+
- **NK cells**: GNLY+, NKG7+
- **Dendritic cells**: FCER1A+, CST3+
- **Platelets**: PPBP+
- **Script**: `05_scrna_annotation.R`

#### 4. Differential Expression Analysis
- Compared CD14+ vs FCGR3A+ monocyte populations
- Identified [X] significantly DE genes (|log2FC| > 0.5, padj < 0.05)
- **Script**: `06_scrna_deg.R`

---

### Part 2: Spatial Transcriptomics Analysis

#### 1. Spatial Data Loading & QC
- Loaded H5 expression matrix + spatial coordinates + tissue image
- QC metrics visualized both as traditional plots AND on tissue
- Mean genes per spot: ~[X]
- **Script**: `09_spatial_load_qc.R`

#### 2. Spatial Clustering
- Normalization: SCTransform
- Dimensionality reduction: PCA (30 components)
- Identified [X] spatially distinct clusters
- **Key insight**: Clusters correspond to anatomical brain regions
- **Script**: `10_spatial_clustering.R`

#### 3. Spatially Variable Genes
- Used Moran's I to identify genes with spatial patterns
- Top spatially variable genes show region-specific expression
- Visualized expression patterns directly on tissue sections
- **Script**: `11_spatial_variable_genes.R`

#### 4. Spatial Domain Characterization
- Identified marker genes for each spatial cluster
- Characterized major brain regions (cortex, white matter, etc.)
- Mapped regional gene expression patterns
- **Scripts**: `12_spatial_markers.R`, `13_spatial_domains.R`

---

## Key Results

### Single-Cell Analysis
- Successfully identified 9 immune cell populations
- Characterized monocyte heterogeneity
- Cell composition: [add percentages]

### Spatial Analysis
- Mapped [X] distinct spatial domains in brain tissue
- Identified spatially variable genes with region-specific patterns
- Characterized cortical vs subcortical gene expression

### Comparison
- Demonstrated understanding of both technologies
- scRNA-seq: High cellular resolution, no spatial context
- Spatial: Spatial context preserved, multi-cell resolution
- Complementary approaches for tissue analysis

---

## Figures

| Analysis | Figure | Description |
|----------|--------|-------------|
| **Single-Cell** |
| | ![QC](figures/01_scrna_qc_before_filter.png) | Quality control metrics |
| | ![UMAP](figures/09_scrna_umap_celltypes.png) | Cell type annotation |
| | ![Volcano](figures/12_scrna_volcano.png) | Monocyte differential expression |
| **Spatial** |
| | ![Tissue](figures/20_spatial_clusters_on_tissue.png) | Spatial clusters on tissue |
| | ![SVGs](figures/22_spatial_variable_genes_tissue.png) | Spatially variable genes |
| | ![Markers](figures/27_spatial_markers_on_tissue.png) | Cluster markers on tissue |

---

## Methods

### Software & Packages
- R version 4.x
- Seurat v4.x/v5.x
- dplyr, ggplot2, patchwork, viridis
- hdf5r (for spatial data)

### Statistical Methods
- **Normalization**: LogNormalize (scRNA-seq), SCTransform (spatial)
- **Differential expression**: Wilcoxon rank-sum test
- **Spatial variable genes**: Moran's I statistic
- **Multiple testing correction**: Bonferroni

### Computational Environment
- Analysis performed on [system specs]
- Total runtime: ~6-8 hours

---

## Repository Structure
```
scrna-spatial-analysis/
├── README.md
├── data/
│   ├── scrna/              # Single-cell PBMC data
│   └── spatial/            # Spatial brain data
├── scripts/
│   ├── 01-07_*.R          # Single-cell analysis pipeline
│   ├── 08-14_*.R          # Spatial analysis pipeline
├── figures/                # All generated plots (30+ figures)
└── results/                # Output tables, RDS objects, CSVs
```

---

## Reproducibility

### Prerequisites
```r
install.packages(c('Seurat', 'dplyr', 'ggplot2', 'patchwork', 'hdf5r', 'viridis'))
```

### Run Analysis
```bash
# Clone repository
git clone https://github.com/[username]/scrna-spatial-analysis.git
cd scrna-spatial-analysis

# Download data (see instructions in scripts/)

# Run analyses in order
Rscript scripts/01_scrna_preprocessing_qc.R
# ... continue through all scripts
Rscript scripts/14_scrna_spatial_comparison.R
```

---

## Skills Demonstrated

### Technical Skills
✅ Single-cell RNA-seq data preprocessing and QC  
✅ Spatial transcriptomics data handling and visualization  
✅ Dimensionality reduction (PCA, UMAP)  
✅ Unsupervised clustering algorithms  
✅ Cell type annotation using marker genes  
✅ Differential expression analysis  
✅ Spatially variable gene identification  
✅ Spatial domain mapping  
✅ Data visualization and interpretation  
✅ Reproducible workflow development  
✅ Git/GitHub version control  

### Biological Understanding
✅ PBMC immune cell populations  
✅ Canonical immune cell markers  
✅ Brain tissue architecture  
✅ Spatial gene expression patterns  
✅ Tissue microenvironment analysis  

---

## Applications & Future Directions

This analysis pipeline can be adapted for:
- **Tumor microenvironment mapping** (immune infiltration, spatial niches)
- **Developmental biology** (tissue organization, cell fate)
- **Immunology** (tertiary lymphoid structures, immune niches)
- **Neuroscience** (brain region characterization)
- **Disease modeling** (spatial patterns in pathology)

---

## Contact
**Akshayata Naidu, PhD**  
Email: akshyata.naidu@gmail.com  
LinkedIn: [profile]  
GitHub: [username]

---

## Acknowledgments
- Datasets: 10X Genomics
- Analysis framework: Seurat (Satija Lab)
- Tutorials and documentation: Seurat vignettes, OSCA book

---

## License
This is an educational/portfolio project. Data are publicly available from 10X Genomics.

---

**Last Updated**: [Date]  
**Analysis Time**: 3 days (24 hours total)  
**Number of Scripts**: 14  
**Number of Figures**: 30+  
**Lines of Code**: ~1,500
```

---

**Push to GitHub:**

```bash
# Add everything
git add scripts/ figures/ results/*.csv README.md .gitignore

# Commit
git commit -m "Complete scRNA-seq and spatial transcriptomics analysis portfolio"

# Create repo on GitHub, then:
git remote add origin https://github.com/[username]/scrna-spatial-analysis.git
git branch -M main
git push -u origin main
```

---

## ✅ WHAT YOU CAN NOW CLAIM

### On Your CV:
```
Independent Single-Cell and Spatial Transcriptomics Projects | December 2024
• Completed comprehensive analysis of scRNA-seq data (2,700 cells) and spatial 
  transcriptomics data (3,600 spots) with full documentation on GitHub
• Performed cell type annotation, differential expression, and spatial domain mapping
• Identified spatially variable genes and characterized tissue architecture
• Developed reproducible analysis pipelines integrating both technologies
• GitHub: github.com/[username]/scrna-spatial-analysis
```

### In Interviews for Koplev Lab Position:

**"Tell me about your spatial transcriptomics experience"**

✅ HONEST ANSWER:
"I recognized spatial transcriptomics as a critical emerging skill, so I completed an independent project analyzing 10X Visium brain data. I performed the full spatial workflow - loading spatial coordinates and images, identifying spatially variable genes using Moran's I, mapping spatial domains, and visualizing expression patterns on tissue sections.

I also completed a parallel scRNA-seq analysis to understand how these technologies complement each other. While I'm still building depth—especially with more complex tissues and integration methods—I understand the core concepts and workflows. I documented everything on GitHub [show repo].

My background in network biology and systems immunology positions me well for spatiotemporal modeling of immune niches. I'm excited to apply these skills to understanding immune architectures in cardiovascular and inflammatory diseases."

---

## TIMELINE SUMMARY

| Day | Hours | Focus | Output |
|-----|-------|-------|--------|
| 1 | 8 | scRNA-seq basics | Clustering, markers |
| 2 | 8 | scRNA-seq advanced + spatial intro | DEG, annotation, spatial prep |
| 3 | 8 | Spatial transcriptomics | Full spatial analysis |
| **Total** | **24** | **Both technologies** | **30+ figures, GitHub repo** |

---

## SUCCESS METRICS

By end of Day 3:
✅ 14 scripts (7 scRNA, 7 spatial)  
✅ 30+ high-quality figures  
✅ Complete README with both analyses  
✅ Results files (CSVs, RDS objects)  
✅ GitHub repository  
✅ **Can discuss BOTH technologies confidently**  
✅ **Ready to apply for Koplev position!**  

---

## PROBABILITY UPDATE

**After completing this bootcamp:**

**Koplev Lab Position Probability: 30-40%** ⬆️⬆️

**Why the big jump?**
- ✅ You'll have SPATIAL experience (was a critical gap)
- ✅ Plus single-cell experience
- ✅ GitHub portfolio demonstrating both
- ✅ Can speak intelligently about spatial methods
- ✅ Shows serious initiative and learning ability
- ✅ Immunology + computational skills remain strong

**This is now a REALISTIC shot!**

---

## FINAL TIPS

**DO:**
✅ Spread over 3 days (don't try to do 24 hours straight!)  
✅ Take breaks between scripts  
✅ Actually look at and understand your results  
✅ Read about the biology (brain regions, immune cells)  
✅ Commit to git after each script  
✅ Celebrate your progress!  

**DON'T:**
❌ Copy-paste without understanding  
❌ Skip the spatial analysis (it's the key addition!)  
❌ Rush through Day 3  
❌ Forget to document as you go  
❌ Apply to Koplev before completing this  

---

**START THIS WEEKEND!**

By Monday, you'll have:
- Real spatial transcriptomics experience
- Real single-cell experience  
- A killer GitHub portfolio
- Confidence to apply to the Koplev position

**This changes everything.** 🚀

Ready to begin? Let's go! 💪
